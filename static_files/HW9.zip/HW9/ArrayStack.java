
public class ArrayStack<T> implements Stack<T> {
    private final int DEFAULT_CAPACITY = 10;
    private int count;
    private T[] array;

    /**
     *    Creates an empty stack using the default capacity.
     */
    public ArrayStack() {
        count = 0;
        array = (T[])(new Object[DEFAULT_CAPACITY]);
    }

    /**
     *  Adds the specified element to the top of this stack, expanding
     *  the capacity of the stack array if necessary.
     */
    public void push(T element) {
        if (count == array.length) {
            expandCapacity();
        }

        array[count] = element;
        count++;
    }

    public T pop() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("Tried popping from an empty stack.");
        }

        count--;
        T result = array[count];
        array[count] = null;

        return result;
    }

    public T peek() {
        if (this.isEmpty()) {
            throw new EmptyCollectionException("Tried peeking at an empty stack.");
        }

        return array[count - 1];
    }

    public boolean isEmpty() {
        return this.count == 0;
    }

    public int size() {
        return this.count;
    }

    /**
     *  Returns a string representation of this stack.
     */
    public String toString() {
        String result = "<bottom of stack>\n";

        for (int i = 0; i < this.count; i++) {
            result += this.array[i].toString() + "\n";
        }

        return result + "<top of stack>";
    }

    /**
     *  Helper method.
     *  Creates a new array to store the contents of this stack with
     *  twice the capacity of the old one.
     */
    private void expandCapacity() {
        T[] larger = (T[])(new Object[array.length*2]);

        for (int index=0; index < array.length; index++)
            larger[index] = array[index];

        array = larger;
    }
    
    public static void main(String[] args) {
        Stack<Integer> s = new ArrayStack<Integer>();
        System.out.println("Created new stack. isEmpty returns " + s.isEmpty());
        
        try {
            System.out.println("\nTrying to pop an empty stack. Expecting an exception.");
            s.pop();
        } catch (EmptyCollectionException e) {
            System.out.println("...Exception successfully thrown (and caught).");
        }
        
        System.out.println("\nAdding numbers 1-20 to stack. Got:");
        for(int i = 0; i < 20; i++) {
            s.push(i + 1);
        }
        System.out.println(s);
        
        System.out.println("\nPopping 10 times Got:");
        for(int i = 0; i < 10; i++) {
            s.pop();
        }
        System.out.println(s);
        
        System.out.println("\nPopping 10 more times Got:");
        for(int i = 0; i < 10; i++) {
            s.pop();
        }
        System.out.println(s);
    }
}
