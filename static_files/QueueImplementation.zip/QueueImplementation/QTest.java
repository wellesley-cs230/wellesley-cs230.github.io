import javafoundations.Queue;
import javafoundations.ArrayQueue;
/**
 * (Start of a) client to help you test your Queue implementations.
 * Currently using the ArrayQueue implementation -- Edit it for your needs
 *
 * @author CS230 Staff 
 * @version 2022.10.25
 */
public class QTest
{
    public static void main(String[] args){
        Queue waitList = new ArrayQueue<String>(); 
        System.out.println("Is new waitlist empty? " + waitList.isEmpty());
        waitList.enqueue ("Aly");
        waitList.enqueue ("Bea");
        // one spot opened
        System.out.println("Enroll: " + waitList.dequeue());
        waitList.enqueue ("Cat");
        waitList.enqueue ("Duo");
        System.out.println("Number of students in waitList: " + waitList.size());
        // Allow everyone to enroll
        while (!waitList.isEmpty()){
            System.out.println("Enroll: " + waitList.dequeue());
        }

    }
}
