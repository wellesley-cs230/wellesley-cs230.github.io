package javafoundations;

import javafoundations.exceptions.*;
/********************************************************************
  LinkedQueue.java       
  @author Java Foundations
  Represents a linked implementation of a queue.
 ********************************************************************/

public class LinkedQueue<T> implements Queue<T>
{
   private int count;
   private LinearNode<T> front, rear;

   //-----------------------------------------------------------------
   //  Creates an empty queue.
   //-----------------------------------------------------------------
   public LinkedQueue()
   {
      count = 0;
      front = rear = null;
   }

   //-----------------------------------------------------------------
   //  Adds the specified element to the rear of this queue.
   //-----------------------------------------------------------------
   public void enqueue (T element)
   {
      LinearNode<T> node = new LinearNode<T>(element);

      if (count == 0)
         front = node;
      else
         rear.setNext(node);

      rear = node;
      count++;
   }

   //-----------------------------------------------------------------
   //  The following methods are left as Programming Projects.
   //-----------------------------------------------------------------

   public T dequeue () throws EmptyCollectionException { return null;}
   public T first () throws EmptyCollectionException { return null;}
   public int size() { return -1;}
   public boolean isEmpty() { return false;}
   public String toString() { return "Not Implemented yet";}
}
